/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年6月27日10:58:20
 * @file    :
 * @brief   :串口打开、关闭、发送
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 打开串口
 * 关闭串口
 * 数据发送
 ***********************************************************************************************************
 */
package com.nx.vfremake.funClass

import android.serialport.SerialPort
import android.util.Log
import com.nx.vfremake.VariableFertViewModel
import com.nx.vfremake.mSerialPortCAN
import com.nx.vfremake.mSerialPortDB9
import java.io.File
import java.io.IOException

class MySerialPortFun {

    /**
     *  打开串口资源
     * @note
     */
    fun openSerialPort(viewModel: VariableFertViewModel) {
        // ttyUW1:CAN 115200 波特率可以调，参考CSM100T用户手册
        try {
            // 默认配置8数据位，1停止位
            mSerialPortDB9 = SerialPort(File("/dev/ttyUW3"), 230400)
            // 这里的can本质上是收:can->串口，发:串口->can
            // 配置can波特率需要为串口波特率的3倍以上，500k
            mSerialPortCAN = SerialPort(File("/dev/ttyUW1"), 115200)
            viewModel.serialPortIsRunning.value = true
        } catch (e: IOException) {
            Log.e("SerialPortInit", "不存在或无法打开: " + e.message)
        } catch (e: SecurityException) {
            Log.e("SerialPortInit", "没有足够的权限: " + e.message)
        } catch (e: Exception) {
            Log.e("SerialPortInit", "其他异常: " + e.message)
        }
    }

    /**
     *  释放串口资源
     * @note 释放串口要出门关闭使用串口的线程和功能函数，以免获取输入流错误
     */
    fun releaseSerialPort(viewModel: VariableFertViewModel) {
        try {
            // 先关闭线程，再关闭串口
            mSerialPortDB9?.tryClose()
            mSerialPortCAN?.tryClose()
            viewModel.serialPortIsRunning.value = false
        } catch (e: IOException) {
            Log.e("SerialPort", "串口资源释放异常:" + e.message)
        }
    }

    /**
     * CAN发送信息给单片机
     * @param  data:数据
     * @return
     * @note
     */
    fun slaveCanMsgSend(data: ByteArray) {
        val outputStream = mSerialPortCAN?.outputStream
        if (outputStream != null) {
            try {
                outputStream.write(data)
                outputStream.flush()
            } catch (e: IOException) {
                Log.e("slaveCanMsgSend", "IOException: " + e.message)
            }
        } else {
            Log.e("SerialPort", "SerialPort已经关闭，无法写出数据")
        }
    }
}
