package com.nx.vfremake.coroutine

import android.util.Log
import com.nx.vfremake.VariableFertViewModel
import com.nx.vfremake.fittingCoefficientA
import com.nx.vfremake.fittingCoefficientB
import com.nx.vfremake.funClass.ConvAndCtrlFun
import com.nx.vfremake.mRmcData
import com.nx.vfremake.mSPParamData
import com.nx.vfremake.mSerialPortCAN
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

//... 接收单片机的数据协程
class CanReceiveCoroutine {
    var isRunning = false

    // 定义一个协程作用域，保存作业引用的HashSet，以便于管理
    private val scope = CoroutineScope(Dispatchers.Default)
    private val jobs = HashSet<Job>()

    fun shutdown() {
        isRunning = false
        jobs.forEach { it.cancel() }
        jobs.clear() // 清空作业记录
    }

    fun start(mVariableFertViewModel: VariableFertViewModel) {

        val confertflow = DoubleArray(mSPParamData.rowNumber)
        val monfertAdcv = DoubleArray(mSPParamData.rowNumber)
        val monAdcV = DoubleArray(mSPParamData.rowNumber)
        val motorSpeed = DoubleArray(mSPParamData.rowNumber)

        // 在协程作用域内启动协程
        jobs.add(scope.launch {
            val inputStreamCAN = mSerialPortCAN?.inputStream
            var buffer = mutableListOf<Byte>() // 辅助缓冲区，用于存储读取的所有字节
            val messageSize = 10 // 每条CAN消息的大小

            try {
                val tempBuffer = ByteArray(64) // 临时缓冲区，用于从inputStreamCAN读取数据
                var dataSize: Int
                while (isActive) {
                    if (inputStreamCAN == null || withContext(Dispatchers.IO) { inputStreamCAN.available() } == 0) {
                        // 如果CAN输入流没有消息，休息10ms停止执行后续代码，重新while
                        delay(10)
                        continue
                    }
                    try {
                        dataSize =
                            withContext(Dispatchers.IO) { inputStreamCAN.read(tempBuffer) }
                        // 将接收到的数据添加到辅助缓冲区中
                        buffer.addAll(tempBuffer.copyOfRange(0, dataSize).toTypedArray())
                        // 循环处理辅助缓冲区中的所有完整消息，直到缓冲区长度小于messageSize
                        while (buffer.size >= messageSize) {
                            // 提取一条完整的CAN消息
                            val message = buffer.take(messageSize).toByteArray()
                            // 移除已经处理的数据
                            buffer = buffer.drop(messageSize).toMutableList()
                            // 处理提取出的CAN消息
                            onSlaveCanMessageReceived(
                                message,
                                confertflow,
                                monfertAdcv,
                                monAdcV,
                                motorSpeed
                            )
                        }

                        // 更新流量信息
                        val mon = monfertAdcv.copyOf()
                        val con = confertflow.copyOf()
                        mVariableFertViewModel.monfertflow.postValue(mon)
                        mVariableFertViewModel.confertflow.postValue(con)
                        mVariableFertViewModel.monAdcV.postValue(monAdcV)
                        mVariableFertViewModel.motorSpeed.postValue(motorSpeed)

                    } catch (e: IOException) {
                        Log.e("CanReceiveCoroutine", "IOException: ${e.message}")
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        })
        isRunning = true
    }

    /**
     * 接收CAN消息后处理
     * @param  message:单片机发送消息经模块转换后，格式 27 07 00 00 27 01 02 03 04 39
     * @param  confertflow:存储转换肥量的数组
     * @param  monfertAdcv:存储采集电压的数组，目前存储的还是adcV
     * @return
     * @note   这里的处理需要和单片机联动，这里单片机发送的消息是4字节即数据域字节，如果需要发送接收更多字节，单片机代码和这里都要修改
     * @note   注意一定要转成UByte，否则uint8_t中128-256会被解析成负值
     */
    private fun onSlaveCanMessageReceived(
        message: ByteArray,
        confertflow: DoubleArray,
        monfertAdcv: DoubleArray,
        monAdcV: DoubleArray,
        motorSpeed: DoubleArray
    ) {
        // 检查消息首尾，如果不满足条件，则不进行处理
        if (message.first() != 0x27.toByte() || message.last() != 0x39.toByte()) {
            Log.e("CanReceiveCoroutine", "无效的CAN信息: ${message.contentToString()} ")
            return
        }
        // 提取CANmsg数据域
        val canDataField = message.sliceArray(5..8) // message[5]到message[8]

        // message[4]是从机的标识符
        //检测流量为数据域[0][1]，转换流量为[2][3]，注意一定要转成UByte，否则uint8_t中128-256会被解析成负值
        val slaveId = message[4].toInt()
        val speedrpm =
            canDataField[0].toUByte().toInt() + (canDataField[1].toUByte().toInt()) * 0.01
        // 电机转速小于3，认为转速为0
        if (speedrpm >= 3) {
            confertflow[slaveId] =
                ConvAndCtrlFun().motorSpeedToFert(
                    speedrpm,
                    mRmcData.forwardSpeedCalculate,
                    mSPParamData.rowSize,
                    fittingCoefficientA[slaveId],
                    fittingCoefficientB[slaveId]
                )
        } else {
            confertflow[slaveId] = 0.0
        }
        motorSpeed[slaveId] = speedrpm
        val fertadcV =
            // 模拟值
//            (canDataField[2].toUByte().toInt() * 100 + canDataField[3].toUByte().toInt()).toDouble()
            // 转换为电压值
            (canDataField[2].toUByte().toInt() * 100 + canDataField[3].toUByte().toInt()) / 4095.0 * 3.3

        monAdcV[slaveId] = fertadcV

        monfertAdcv[slaveId] = fertadcV

        //...接收数据测试代码
        val monfertAdcvi = monfertAdcv[slaveId]
        val confertflowi = confertflow[slaveId]
        val messagepr = message.joinToString(separator = " ") {
            String.format("%02X", it)
        }
        val hexString = canDataField.joinToString(separator = " ") {
            String.format("%02X", it)
        }
        Log.d(
            "CanReceiveCoroutine",
            "$slaveId ReceiveMsg: $messagepr\n$hexString\nmonfertAdcv: $monfertAdcvi  confertflow: $confertflowi"
        )
        //...
    }
}
