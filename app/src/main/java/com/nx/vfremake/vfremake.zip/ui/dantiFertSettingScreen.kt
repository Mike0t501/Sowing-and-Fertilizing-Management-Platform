/**
 ************************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年10月9日20:46:01
 * @file    :
 * @brief   :单体排肥转速-流量设置
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 *
 ***********************************************************************************************************
 */
package com.nx.vfremake.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nx.vfremake.R
import com.nx.vfremake.funClass.MydantiFertSharedPre
import com.nx.vfremake.funClass.TableRow

private var backPressedTime: Long = 0

@Composable
fun DantiFertSettings(onClickBack: () -> Unit = {}) {
    val context = LocalContext.current

    val tableRowsRemember =
        remember { mutableStateOf(MydantiFertSharedPre(context).getTableRows()) }

    fun addTableRow(id: Int = 0, a: String = "0", b: String = "0") {
        val newRow = TableRow(id, a, b)
        val updatedList = tableRowsRemember.value + newRow
        tableRowsRemember.value = updatedList
        MydantiFertSharedPre(context).saveTableRow(newRow.id, newRow)
    }

    //...添加单体
    val showABDialog = remember { mutableStateOf(false) }
    if (showABDialog.value) {
        Dialog(onDismissRequest = {
            showABDialog.value = false
        }) {
            val id = remember { mutableStateOf("0") }
            val a = remember { mutableStateOf("0") }
            val b = remember { mutableStateOf("0") }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .padding(dimensionResource(id = R.dimen.middle_view_padding))
                        .fillMaxWidth(0.8f)
                        .clip(RoundedCornerShape(dimensionResource(id = R.dimen.big_roundedCornerShape)))
                        .background(Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(dimensionResource(id = R.dimen.middle_view_padding)),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding))
                    ) {
                        Text(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally),
                            text = "设置单体",
                            style = TextStyle(
                                fontWeight = FontWeight.W600,
                                fontSize = 20.sp,
                                letterSpacing = 2.sp,
                                textAlign = TextAlign.Center
                            ),
                        )
                        MyDiyTextField(
                            value = id.value,
                            label = "单体: ",
                            onValueChange = { newText ->
                                id.value = newText
                            },
                        )
                        MyDiyTextField(value = a.value,
                            label = "A: ",
                            onValueChange = { newText ->
                                a.value = newText
                            }
                        )
                        MyDiyTextField(value = b.value,
                            label = "B: ",
                            onValueChange = { newText ->
                                b.value = newText
                            }
                        )
                        IconButton(onClick = {
                            addTableRow(id.value.toInt(), a.value, b.value)
                            showABDialog.value = false
                        }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "添加单体"
                            )
                        }
                    }
                }
            }
        }
    }
    //... 添加单体结束

    Scaffold(
        topBar = {
            MyTopBar(
                title = "单体转速流量设置 : ax+b",
                onClickBack = {
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - backPressedTime < 1000) {
                        Log.d("TopBar", "返回防抖已运行")
                        return@MyTopBar
                    }
                    backPressedTime = currentTime
                    onClickBack()
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(innerPadding),
        ) {
            // 显示行数据的 Composable
            Column(
                modifier = Modifier.padding(dimensionResource(id = R.dimen.big_view_padding)),
                verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding))
            ) {
                tableRowsRemember.value.forEach { row ->
                    TemplatesSettingsRow(
                        text = if (row.id == 0) {
                            "除特殊设置外的单体"
                        } else {
                            "单体 " + row.id
                        },
                        onLongClick = {
                            MydantiFertSharedPre(context).deleteTableRow(row.id)
                            tableRowsRemember.value = MydantiFertSharedPre(context).getTableRows()
                        },
                        content = {
                            MyDiyTextField(
                                label = "系数a: ",
                                modifier = Modifier.width(150.dp),
                                value = row.a,
                                readOnly = true
                            )

                            MyDiyTextField(
                                label = "系数b: ",
                                modifier = Modifier
                                    .width(150.dp)
                                    .padding(end = dimensionResource(id = R.dimen.middle_view_padding) * 2),
                                value = row.b,
                                readOnly = true
                            )
                        }
                    )
                }
                TemplatesSettingsRow(
                    text = "添加单体",
                    content = {
                        IconButton(
                            onClick = {
                                showABDialog.value = true
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "添加单体"
                            )
                        }
                    }
                )
            }
        }
    }
}
