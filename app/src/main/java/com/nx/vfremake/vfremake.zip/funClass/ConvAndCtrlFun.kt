/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年6月29日15:43:02
 * @file    :
 * @brief   :施肥量<->转速转换，生成控制信息
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 施肥量<->转速转换
 * CAN控制信息生成
 ***********************************************************************************************************
 */
package com.nx.vfremake.funClass

import android.util.Log

class ConvAndCtrlFun {

    /**
     * 电机转速转换施肥量
     * @param  motorSpeedrpm:电机转速
     * @param  forwardSpeed:前进速度
     * @param  rowSize:行距
     * @return fert:肥量kg/亩
     * @note
     */
    fun motorSpeedToFert(
        motorSpeedrpm: Double,
        forwardSpeed: Double,
        rowSize: Double,
        fittingCoefficientA: Double,
        fittingCoefficientB: Double
    ): Double {
        val fertflow: Double = fittingCoefficientA * motorSpeedrpm + fittingCoefficientB
        val fert = fertflow * 3.6 / (1000.0 * rowSize * 0.0015 * forwardSpeed)
        return fert
    }

    /**
     * 施肥量转换电机转速
     * @param  fert:施肥量kg/亩
     * @param  forwardSpeed:用于计算的前进速度
     * @param  rowSize:行距
     * @return motorSpeedrpm:电机转速
     * @note
     */
    fun fertToMotorSpeed(
        fert: Double,
        forwardSpeed: Double,
        rowSize: Double,
        fittingCoefficientA: Double,
        fittingCoefficientB: Double
    ): Double {
        val motorSpeedrpm: Double
        val fertflow = fert * 1000.0 * rowSize * 0.0015 * forwardSpeed / 3.6
        motorSpeedrpm = (fertflow - fittingCoefficientB) / fittingCoefficientA
        return motorSpeedrpm
    }

    /**
     * 施肥量转换电机转速
     * @param  fertflow:流量
     * @return motorSpeedrpm:电机转速
     * @note
     */
    fun fertflowToMotorSpeed(
        fertflow: Double,
        fittingCoefficientA: Double,
        fittingCoefficientB: Double
    ): Double {
        val motorSpeedrpm = (fertflow - fittingCoefficientB) / fittingCoefficientA
        Log.d("Convert", "流量-转速")
        return motorSpeedrpm
    }

    /**
     * 发送控制信息
     * @param  motorSpeedrpm:电机转速
     * @param  i:单体
     * @return
     * @note   这里设置了电机转速阈值，根据实际更改
     */
    @OptIn(ExperimentalUnsignedTypes::class)
    fun motorSpeedrpmSend(motorSpeedrpm: Double, i: Int) {

        // 电机启停标志位
        val motorStartFlag = if (motorSpeedrpm >= 3) 0x01.toUByte() else 0x00.toUByte()
        val ctrlIntPart = motorSpeedrpm.toInt()
        val ctrlDecimalPart = ((motorSpeedrpm - ctrlIntPart) * 100).toInt()
        // 如果启停标志位为00，则设置目标转速默认值为60rpm，方便后续控制
        val ctrlIntPartByte =
            if (motorStartFlag == 0x00.toUByte()) 0x00.toUByte() else ctrlIntPart.toUByte()
        val ctrlDecimalPartByte =
            if (motorStartFlag == 0x00.toUByte()) 0x00.toUByte() else ctrlDecimalPart.toUByte()

        // canMessageSend格式 27 0B 00 00 27 00 01 02 03 04 05 06 07 39
        val canMessageSend = ubyteArrayOf(
            0x27.toUByte(),
            0x08.toUByte(),
            0x00.toUByte(),
            0x00.toUByte(),
            0x27.toUByte(),
            0x00.toUByte(),
            i.toUByte(),
            motorStartFlag,
            ctrlIntPartByte,
            ctrlDecimalPartByte,
            0x39.toUByte()
        )
        MySerialPortFun().slaveCanMsgSend(canMessageSend.toByteArray())

        //...CANmsg测试代码
        val hexString = canMessageSend.toByteArray().joinToString(separator = " ") {
            String.format("%02X", it)
        }
        Log.d("CtrlMsg", "SendMsg $i: $hexString")
        //...
    }
}
