/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年6月29日15:17:24
 * @file    :
 * @brief   :主界面compose
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 左右侧信息栏
 * mapview
 * 全屏视图、位置跟踪、清除、合并已施肥区域图层
 * 菜单栏
 * 更换处方图悬浮dialog
 ***********************************************************************************************************
 */
package com.nx.vfremake.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.DropdownMenu
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LayersClear
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Merge
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.esri.arcgisruntime.geometry.Envelope
import com.esri.arcgisruntime.geometry.Point
import com.esri.arcgisruntime.geometry.SpatialReferences
import com.esri.arcgisruntime.mapping.Viewpoint
import com.esri.arcgisruntime.mapping.view.MapView
import com.esri.arcgisruntime.symbology.PictureMarkerSymbol
import com.nx.vfremake.R
import com.nx.vfremake.VariableFertViewModel
import com.nx.vfremake.fittingCoefficientA
import com.nx.vfremake.fittingCoefficientB
import com.nx.vfremake.funClass.ConvAndCtrlFun
import com.nx.vfremake.funClass.DocuAndManageFun
import com.nx.vfremake.funClass.ExportGeoFun
import com.nx.vfremake.funClass.MyArcGisFun
import com.nx.vfremake.funClass.MySerialPortFun
import com.nx.vfremake.funClass.MySharedPreFun
import com.nx.vfremake.mSPParamData
import com.nx.vfremake.selectLoadShpFileLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

// 视图集合
/**
 * 主视图合集
 * @param  mapView:mapview视图
 * @param  mVariableFertViewModel:更新地图UI viewmodel
 * @param  mVariableFertViewModel:更新信息栏UI viewmodel
 * @param  onClickSettigns:从设置界面返回所要实现功能
 * @param  onClickParamSet:从参数设置界面返回所要实现功能
 * @return
 * @note   mapview视图为了保证更改才重建，从顶层compose里注入
 */
@Composable
fun MainScreen(
    mapView: MapView,
    mVariableFertViewModel: VariableFertViewModel,
    onClickSettigns: () -> Unit = {},
    onClickParamSet: () -> Unit = {}
) {
    Box(modifier = Modifier.background(Color(LocalContext.current.getColor(R.color.background_color_night)))) {
        MapAndFunBontonVeiw(mapView, mVariableFertViewModel)
        MsgScreenRight(mVariableFertViewModel)
        MsgScreenBottom(mVariableFertViewModel)
        MenuBottomBar(mapView, mVariableFertViewModel, onClickSettigns, onClickParamSet)
    }
}

/**
 * mamview视图和小功能按钮视图
 * @param  mapView:mapview视图
 * @param  mVariableFertViewModel:更新地图UI viewmodel
 * @return
 * @note   mapview视图为了保证更改才重建，从顶层compose里注入
 */
@Composable
fun MapAndFunBontonVeiw(mapView: MapView, mVariableFertViewModel: VariableFertViewModel) {

    val context = LocalContext.current
    val mArcGISMap by mVariableFertViewModel.mArcGISMap.observeAsState()
    val shapefileFeatureLayer by mVariableFertViewModel.shapefileFeatureLayer.observeAsState()
    val navMarkGraphicsOverlay by mVariableFertViewModel.navMarkGraphicsOverlay.observeAsState()
    val fertGraphicsOverlay by mVariableFertViewModel.fertGraphicsOverlay.observeAsState()
    val fertGraphicsOverlayExport by mVariableFertViewModel.fertGraphicsOverlayExport.observeAsState()
    val loLaDidegData by mVariableFertViewModel.loLaDidegData.observeAsState(Triple(0.0, 0.0, 0.0))

    // 当前位置跟踪标志位
    val navCenterIsRunning = remember { mutableStateOf(false) }

    //...检查是否设置sharedpre
    val deltaXSharedPre =
        MySharedPreFun(context).getSpecificValue(R.string.deltaX_name)
    val deltaX = if (!deltaXSharedPre.isNullOrEmpty()) {
        deltaXSharedPre.toInt()
    } else {
        context.resources.getInteger(R.integer.deltaX_value)
    }
    val deltaYSharedPre =
        MySharedPreFun(context).getSpecificValue(R.string.deltaY_name)
    val deltaY = if (!deltaYSharedPre.isNullOrEmpty()) {
        deltaYSharedPre.toInt()
    } else {
        context.resources.getInteger(R.integer.deltaX_value)
    }
    //...检查是否设置sharedpre

    // 使用 LaunchedEffect 来响应 loLaDidegData 的变化
    LaunchedEffect(loLaDidegData) {
        while (navCenterIsRunning.value) {
            loLaDidegData?.let { (longitude, latitude, direction) ->
                val point = Point(longitude, latitude, SpatialReferences.getWgs84())
                val deltaXCacu = 0.000001 * deltaX
                val deltaYCacu = 0.000001 * deltaY
                // Viewpoint需要传入的参数是Envelope，这里采用显示区域来设置，上述delta修改可以改表区域大小
                val envelope = Envelope(
                    point.x - deltaXCacu, point.y - deltaYCacu,  // 最小 X 和 Y
                    point.x + deltaXCacu, point.y + deltaYCacu   // 最大 X 和 Y
                    , SpatialReferences.getWgs84()
                )
                val viewpoint = Viewpoint(envelope, direction)
                mapView.setViewpointAsync(viewpoint, 0.3f)
                delay(300)
            }
        }
    }

    // 监听mapview视图旋转角度
    LaunchedEffect(mapView) {
        mapView.addMapRotationChangedListener {
            val rotation = mapView.mapRotation
            mVariableFertViewModel.mapViewRotation.value = rotation
            val graphics = navMarkGraphicsOverlay?.graphics
            if (graphics != null) {
                try {
                    for (graphic in graphics) {
                        if (graphic.symbol is PictureMarkerSymbol) {
                            (graphic.symbol as PictureMarkerSymbol).angle =
                                (loLaDidegData.third - rotation).toFloat()
                        }
                    }
                } catch (e: Exception) {
                    Log.e("跟随当前位置", "graphics集合异常")
                }
            }
        }
    }

    // 跟踪当前位置、视图适应屏幕全图居中、清除fertGraphicsOverlay图层按钮
    //... 防止清除图层误触操作
    val clearFertOverlayState = remember { mutableStateOf(false) }
    if (clearFertOverlayState.value) {
        ShowConfirmDialog(
            title = "清除已施肥区域图层",
            text = "你确实要清除已施肥区域的绘制图层吗？",
            onConfirm = {
//                if (mapView.graphicsOverlays.contains(fertGraphicsOverlay) && fertGraphicsOverlay != null) {
//                    fertGraphicsOverlay?.graphics?.clear()
////                    mapView.post { mapView.invalidate() }
//                }
                if (mapView.graphicsOverlays.contains(fertGraphicsOverlayExport) && fertGraphicsOverlayExport != null) {
                    fertGraphicsOverlayExport?.graphics?.clear()
                }
                mapView.post { mapView.invalidate() }
            },
            showDialog = clearFertOverlayState
        )
    }
    //... 防止清除图层误触操作结束

    //... 防止合并图层误触操作
    val mergeFertOverlayState = remember { mutableStateOf(false) }
    if (mergeFertOverlayState.value) {
        ShowConfirmDialog(
            title = "合并已施肥区域图层",
            text = "你确实要合并已施肥区域的绘制图层吗？",
            onConfirm = {
                if (mapView.graphicsOverlays.contains(fertGraphicsOverlay) && fertGraphicsOverlay != null) {
                    // 0.3m 对应的角度制为0.000002703，这个只在最后的时候使用，因为每次调用都会大一圈
                    fertGraphicsOverlay?.let {
                        MyArcGisFun().mergeGraphicsWithBuffer(
                            it,
                            0.0,
                            context
                        )
                    }
                }
            },
            showDialog = mergeFertOverlayState
        )
    }
    //... 防止合并图层误触操作结束
    //... 防止合并图层误触操作
    val exportFertOverlayState = remember { mutableStateOf(false) }
    if (exportFertOverlayState.value) {
        ShowConfirmDialog(
            title = "导出已施肥区域图层",
            text = "你确实要导出已施肥区域的绘制图层吗？",
            onConfirm = {
//                if (mapView.graphicsOverlays.contains(fertGraphicsOverlay) && fertGraphicsOverlay != null) {
//                    fertGraphicsOverlay?.let {
//                        Log.d("Geodatabase Export", "导出开始")
//                        ExportGeoFun(context).createGeodatabase(it)
//                    }
//                    mapView.post { mapView.invalidate() }
//                }
                if (mapView.graphicsOverlays.contains(fertGraphicsOverlayExport) && fertGraphicsOverlayExport != null) {
                    fertGraphicsOverlayExport?.let {
                        Log.d("Geodatabase Export", "导出开始")
                        ExportGeoFun(context).createGeodatabase(it)
                    }
                    mapView.post { mapView.invalidate() }
                }
            },
            showDialog = exportFertOverlayState
        )
    }
    //... 防止合并图层误触操作结束

    val loLaDiData by mVariableFertViewModel.loLaDidegData.observeAsState(Triple(0.0, 0.0, 0.0))

    val colorList by mVariableFertViewModel.colorList.observeAsState(initial = listOf())
    val classBreaksList by mVariableFertViewModel.classBreaksList.observeAsState(initial = listOf())
    // start初始值false，当变为true更新ui
    var shpLoadDone by remember { mutableStateOf(false) }
    // 两个都变化则开始进行 if{}
    LaunchedEffect(colorList, classBreaksList) {
        if (colorList.isNotEmpty() && classBreaksList.isNotEmpty()) {
            shpLoadDone = true
        }
    }

    Box(
        modifier = Modifier
            .padding(dimensionResource(id = R.dimen.small_custom_padding))
            .fillMaxSize(),
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth(0.8f)
                .fillMaxHeight(0.8f),
        ) {
            AndroidView(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxHeight()
                    .fillMaxWidth(),
                factory = { mapView },
                // 当mapview某个观测元素变化时， updata包含的变化元素会自动更新
                update = {
                    // 检查图层是否存在，不存在新建，存在避免重复添加同名图层
                    if (!mapView.graphicsOverlays.contains(navMarkGraphicsOverlay)) {
                        if (navMarkGraphicsOverlay != null) {
                            mapView.graphicsOverlays.add(navMarkGraphicsOverlay)
                        }
                    }

                    if (!mapView.graphicsOverlays.contains(fertGraphicsOverlay)) {
                        if (fertGraphicsOverlay != null) {
                            mapView.graphicsOverlays.add(fertGraphicsOverlay)
                        }
                    }
                    if (!mapView.graphicsOverlays.contains(fertGraphicsOverlayExport)) {
                        if (fertGraphicsOverlayExport != null) {
                            mapView.graphicsOverlays.add(fertGraphicsOverlayExport)
                        }
                    }
                    mArcGISMap.let {
                        mapView.map = it
                        mapView.invalidate()
                    }
                    navMarkGraphicsOverlay.let {
                        // 调用invalidate()方法重绘MapView
                        mapView.invalidate()
                    }
                    fertGraphicsOverlay.let {
                        // 调用invalidate()方法重绘MapView
                        mapView.invalidate()
                    }
                    fertGraphicsOverlayExport.let {
                        // 调用invalidate()方法重绘MapView
                        mapView.invalidate()
                    }
                },
            )
            Column(
                modifier = Modifier
                    .padding(start = dimensionResource(id = R.dimen.big_view_padding))
//                    .align(Alignment.CenterStart),
            ) {

                TemplatesNav_LatiLonti(
                    value = loLaDiData.first,
                    value1 = loLaDiData.second,
                    decimalPlaces = 8,
                    unit = "°"
                )

                Spacer(modifier = Modifier.height(30.dp))

                IconButton(
                    // 因为对视图的操作不是在主线程操作，compose会自动响应变化
                    // 要想手动刷新需要mapView.post { mapView.invalidate() }
                    // 不能直接 mapView.invalidate()，不在主线程操作需要post否则没反应
                    onClick = {
                        if (shapefileFeatureLayer?.fullExtent != null) {
                            val viewpoint = Viewpoint(shapefileFeatureLayer?.fullExtent)
                            mapView.setViewpointAsync(viewpoint, 0.2f)
                            mapView.post { mapView.invalidate() }
                            navCenterIsRunning.value = false
                            mVariableFertViewModel.navCenterIsRunning.value = false
                        }
                    }
                ) {
                    Icon(imageVector = Icons.Filled.Fullscreen, contentDescription = "适应屏幕")
                }

                IconButton(onClick = {
                    navCenterIsRunning.value = !navCenterIsRunning.value
                    mVariableFertViewModel.navCenterIsRunning.value =
                        mVariableFertViewModel.navCenterIsRunning.value != true
                }) {
                    Icon(
                        imageVector = if (navCenterIsRunning.value) Icons.Filled.Explore
                        else Icons.Outlined.Explore,
                        contentDescription = "跟随当前位置"
                    )
                }
                IconButton(onClick = { clearFertOverlayState.value = true }) {
                    Icon(
                        imageVector = Icons.Filled.LayersClear,
                        contentDescription = "清除已施肥区域图层"
                    )
                }

                IconButton(onClick = { mergeFertOverlayState.value = true }) {
                    Icon(imageVector = Icons.Filled.Merge, contentDescription = "合并施肥区域图层")
                }
                IconButton(onClick = { exportFertOverlayState.value = true }) {
                    Icon(imageVector = Icons.Filled.Upload, contentDescription = "导出施肥区域图层")
                }

                if (shpLoadDone) {
                    // 将List类型转换成可编辑类型，要在头部增加一个红色
                    val colors = colorList.toMutableList()
                    // 将Color.RED，0值渲染色插入到color0
                    colors.add(0, context.getColor(R.color.zeroZoneRender_color))
                    // 转换成compose色系，Android原生色系不兼容
                    val parsedColors = colors.map { Color(it) }
                    parsedColors.forEachIndexed { index, color ->
                        Box(
                            modifier = Modifier
                                .padding(dimensionResource(id = R.dimen.colorListTip_padding))
                                .background(color),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = classBreaksList[index], style = TextStyle(
                                    color = Color.Black,
                                    fontFamily = FontFamily(Font(R.font.youshehaoshenti)),
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 底部菜单
 * @param  mapView:mapView
 * @param  mVariableFertViewModel:更新地图UI viewmodel
 * @param  onClickSettigns:导航页面至设置界面
 * @param  onClickParamSet:导航页面至参数设置界面
 * @return
 * @note
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MenuBottomBar(
    mapView: MapView,
    mVariableFertViewModel: VariableFertViewModel,
    onClickSettigns: () -> Unit = {},
    onClickParamSet: () -> Unit = {}
) {
    val context = LocalContext.current
    val sharedPre = MySharedPreFun(context).getMySharedPre()
    val editor = sharedPre.edit()
    val fertValueFieldResKey = context.getString(R.string.fertQueryField_name)

    // 展开/收起菜单逻辑
    val menuIsExpanded = remember { mutableStateOf(false) }
    // 更换处方图界面Dialog
    val showShpMsgDialog = remember { mutableStateOf(false) }

    // 输入字段
    val valueField =
        rememberSaveable {
            mutableStateOf(sharedPre.getString(fertValueFieldResKey, null) ?: "")
        }

    // 从viewmodel加载字段列表
    val fieldList by mVariableFertViewModel.fieldsList.observeAsState()
    // 如果viewmodel字段列表已经赋值完成则加载
    val shpLoadDone = remember { mutableStateOf(false) }
    LaunchedEffect(fieldList) {
        if (!fieldList.isNullOrEmpty()) {
            shpLoadDone.value = true
        }
    }

    //... 如果添加了新shp却没有选择字段则警告开始
    val showNoFieldDialogAlert = remember { mutableStateOf(false) }
    if (showNoFieldDialogAlert.value) {
        ShowConfirmDialog(
            title = "警告",
            text = "请在字段列表中选择任意一项。",
            showDialog = showNoFieldDialogAlert,
            showDismiss = false
        )
    }
    //... 如果添加了新shp却没有选择字段则警告结束

    // 菜单展开栏
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.BottomStart
    ) {
        IconButton(
            modifier = Modifier.padding(start = dimensionResource(id = R.dimen.middle_view_padding)),
            onClick = { menuIsExpanded.value = true }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = "菜单",
                    tint = Color.White
                )
                Text(text = "菜单", color = Color.White)
            }
        }
        DropdownMenu(
            expanded = menuIsExpanded.value,
            onDismissRequest = { menuIsExpanded.value = false }
        ) {
            DropdownMenuItem(
                onClick = {
                    onClickSettigns()
                    menuIsExpanded.value = false // 手动关闭 DropdownMenu
                }
            ) {
                Text("设置")
            }
            DropdownMenuItem(
                onClick = {
                    onClickParamSet()
                    menuIsExpanded.value = false // 手动关闭 DropdownMenu
                }
            ) {
                Text("参数设置")
            }
            DropdownMenuItem(onClick = {
                // 点击更换处方图时，显示悬浮界面
                val shpPath =
                    MySharedPreFun(context).getSpecificValue(R.string.myLoadShpFile_Path_name)
                MyArcGisFun().getFieldList(shpPath, mVariableFertViewModel)
                showShpMsgDialog.value = true
                menuIsExpanded.value = false
            }) {
                Text("更换处方图")
            }
        }
    }

    // 当点击更换处方图后，显示的悬浮界面
    if (showShpMsgDialog.value) {
        Dialog(
            onDismissRequest = {
                val fertFieldResValue = sharedPre.getString(fertValueFieldResKey, null)
                val fieldListValue = fieldList
                // 检查值是否不在 fieldList 中
                if (fieldListValue?.contains(fertFieldResValue) != true) {
                    showNoFieldDialogAlert.value = true
                    // 阻止对话框关闭
                    return@Dialog
                }
                showShpMsgDialog.value = false
            }
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .padding(dimensionResource(id = R.dimen.middle_view_padding))
                        .fillMaxWidth(0.8f)
                        .clip(RoundedCornerShape(dimensionResource(id = R.dimen.big_roundedCornerShape)))
                        .background(Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(bottom = dimensionResource(id = R.dimen.middle_view_padding)),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .background(Color(context.getColor(R.color.light_gray))),
                        ) {
                            Text(
                                modifier = Modifier.align(Alignment.Center),
                                text = "更换处方图",
                                style = TextStyle(
                                    fontWeight = FontWeight.W600,
                                    fontSize = 20.sp,
                                    letterSpacing = 2.sp,
                                    textAlign = TextAlign.Center
                                ),
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = dimensionResource(id = R.dimen.middle_view_padding)),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding))
                        ) {

                            // 输入框
                            MyDiyTextField(
                                label = "字段: ",
                                modifier = Modifier.weight(1f),
                                value = valueField.value,
                                readOnly = true,
                            )

                            // 选择shp文件
                            MyOutlinedButton(
                                onClick = {
                                    DocuAndManageFun().selectShapefile(
                                        selectLoadShpFileLauncher
                                    )
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MoreHoriz,
                                    contentDescription = "选择文件"
                                )
                            }

                            // 重新加载Shp
                            MyOutlinedButton(
                                onClick = {
                                    val fertFieldResValue =
                                        sharedPre.getString(fertValueFieldResKey, null) ?: ""
                                    val fieldListValue = fieldList
                                    // 检查值是否不在 fieldList 中
                                    if (fieldListValue?.contains(fertFieldResValue) != true) {
                                        showNoFieldDialogAlert.value = true
                                        // 阻止对话框关闭
                                        return@MyOutlinedButton
                                    }

                                    // 移除业务图层shp
                                    mapView.map.operationalLayers.toList().forEach {
                                        mapView.map.operationalLayers.remove(it)
                                    }
                                    // 清除覆盖层GraphicsOverlay的graphics
                                    mapView.graphicsOverlays.forEach {
                                        it.graphics.clear()
                                    }
                                    // 移除覆盖层
                                    mapView.graphicsOverlays.forEach {
                                        mapView.graphicsOverlays.remove(it)
                                    }
                                    // 使用CoroutineScope启动一个新的协程
                                    CoroutineScope(Dispatchers.Main).launch {
                                        MyArcGisFun().loadShp(context, mVariableFertViewModel)
                                    }
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "开始"
                                )
                            }
                        }
                    }
                }
                // 字段加载完成，显示在下方
                if (shpLoadDone.value) {
                    FlowRow(
                        modifier = Modifier.padding(dimensionResource(id = R.dimen.small_view_padding)),
                        horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding)),
                        verticalArrangement = Arrangement.Center
                    ) {
                        fieldList?.forEach { field ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(dimensionResource(id = R.dimen.small_roundedCornerShape)))
                                    .background(Color.White)
                                    .align(Alignment.CenterVertically)
                                    .padding(dimensionResource(id = R.dimen.middle_view_padding))
                                    .clickable(
                                        onClick = {
                                            valueField.value = field
                                            editor
                                                .putString(fertValueFieldResKey, field)
                                                .apply()
                                        }
                                    )
                            ) {
                                Text(
                                    text = field,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 左右侧信息栏
 * @param  mVariableFertViewModel:更新地图UI viewmodel
 * @param  mVariableFertViewModel:更新信息栏UI viewmodel
 * @return
 * @note   因为这里有信息栏，也有图层提示，所以有两个viewmodel
 */
@Preview(
    widthDp = 1712,
    heightDp = 1072
)
@Composable
fun MsgScreenRight(
    mVariableFertViewModel: VariableFertViewModel = VariableFertViewModel(),
) {
    // 观察并获得ViewModel中的数据
    val fertApplied by mVariableFertViewModel.fertApplied.observeAsState(DoubleArray(mSPParamData.rowNumber) { 0.0 })

    // 观察并获得ViewModel中的数据
    val loLaDiData by mVariableFertViewModel.loLaDidegData.observeAsState(Triple(0.0, 0.0, 0.0))
    val forwardspeed by mVariableFertViewModel.forwardspeed.observeAsState(0.0)

    val context = LocalContext.current
    val sharedPre = MySharedPreFun(context).getMySharedPre()
    val testSendRemember = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.testMode_testSend_name)
                ?: context.getString(R.string.testMode_testSend_defeatValue)
        )
    }
    val isMotorRpmState = remember {
        mutableStateOf(
            (MySharedPreFun(context).getSpecificValue(R.string.testMode_testSendMode_name)
                ?: context.getString(R.string.testMode_testSendMode_defeatValue)) == "0"
        )
    }

    fun getFormattedTime(): String {
        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        return LocalTime.now().format(formatter)
    }

    var currentTime by remember { mutableStateOf(getFormattedTime()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            currentTime = getFormattedTime()
        }
    }

    // 如果不是固定解，闪烁
    var isVisible by remember { mutableStateOf(true) }
    LaunchedEffect(mVariableFertViewModel.gnssIsGood.value) {
        while (mVariableFertViewModel.gnssIsGood.value == true) {
            isVisible = !isVisible
            delay(500L)
        }
        if (mVariableFertViewModel.gnssIsGood.value == false) {
            isVisible = true
        }
    }

    Box(
        modifier = Modifier
            .padding(dimensionResource(id = R.dimen.small_custom_padding))
            .fillMaxSize(),
    ) {
        // 右侧信息栏
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .fillMaxWidth(0.2f)
                .fillMaxHeight(0.8f),
        ) {
            Column(
                modifier = Modifier.padding(start = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.small_view_padding))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Yellow, shape = RoundedCornerShape(8.dp)),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TemplatesText_Uint(value = forwardspeed, decimalPlaces = 2, uint = "km/h")
                    TemplatesText_Uint(value = loLaDiData.third, decimalPlaces = 2, uint = "°")
                    Column(
                        modifier = Modifier.padding(5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(text = currentTime, style = TextStyle(fontSize = 16.sp))
                        if (isVisible) {
                            Icon(
                                modifier = Modifier.padding(top = 3.dp),
                                imageVector = Icons.Filled.CellTower,
                                contentDescription = "GNSS信号强度",
                            )
                        }
                    }
                }

                //... 转速估值
//                val doubleArray = mVariableFertViewModel.confertflow.value
//                    ?: DoubleArray(mSPParamData.rowNumber) { 0.0 }
//                val doubleArray1 = DoubleArray(mSPParamData.rowNumber) { 0.0 }
//                TemplatesRightMsgText_Value(title = "施肥量(kg/亩)", doubleArray = doubleArray)
//
//                for (i in doubleArray.indices) {
//                    if (fertApplied[i] != 0.0) {
//                        doubleArray1[i] =
//                            100.0 - abs((doubleArray[i] - fertApplied[i]) / fertApplied[i]) * 100
//                    }
//                }
//                TemplatesRightMsgText_Value(title = "准确率(%)", doubleArray = doubleArray1)
                //... 检测值
                val doubleArray = mVariableFertViewModel.monfertflow.value
                    ?: DoubleArray(mSPParamData.rowNumber) { 0.0 }
                val doubleArray1 = DoubleArray(mSPParamData.rowNumber) { 0.0 }
                TemplatesRightMsgText_Value(title = "施肥量(kg/亩)", doubleArray = doubleArray)

                for (i in doubleArray.indices) {
                    if (fertApplied[i] != 0.0) {
                        doubleArray1[i] =
                            100.0 - abs((doubleArray[i] - fertApplied[i]) / fertApplied[i]) * 100
                    }
                }
                mVariableFertViewModel.accuracyDoublearray.postValue(doubleArray1)
                TemplatesRightMsgText_Value(title = "准确率(%)", doubleArray = doubleArray1)
                //...

                // 如果打开了测试模式，会在右侧的UI显示调试信息，方便标定肥量-转速曲线，也方便排查问题
                // 两种模式，一种直接发转速，另一种通过拟合的曲线发流量值
                if (MySharedPreFun(context).getSpecificValue(R.string.testMode_Switch_name) == "1") {
                    Box(modifier = Modifier.background(Color.White, RoundedCornerShape(8.dp))) {
                        Column(
                            modifier = Modifier.padding(start = 5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.small_view_padding))
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(top = dimensionResource(id = (R.dimen.big_view_padding))),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.small_custom_padding))
                            ) {
                                MyDiyTextField(
                                    modifier = Modifier.width(100.dp),
                                    value = testSendRemember.value,
                                    onValueChange = { newText ->
                                        testSendRemember.value = newText
                                        sharedPre.edit()
                                            .putString(
                                                context.getString(R.string.testMode_testSend_name),
                                                newText
                                            ).apply()
                                    }
                                )
                                Column(
                                    modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // 加号按钮
                                    IconButton(
                                        modifier = Modifier.size(20.dp),
                                        onClick = {
                                            testSendRemember.value =
                                                (testSendRemember.value.toInt() + 5).toString()
                                            sharedPre.edit()
                                                .putString(
                                                    context.getString(R.string.testMode_testSend_name),
                                                    testSendRemember.value
                                                ).apply()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowUp,
                                            contentDescription = "+"
                                        )
                                    }

                                    // 减号按钮
                                    IconButton(
                                        modifier = Modifier.size(20.dp),
                                        onClick = {
                                            testSendRemember.value =
                                                (testSendRemember.value.toInt() - 5).toString()
                                            sharedPre.edit()
                                                .putString(
                                                    context.getString(R.string.testMode_testSend_name),
                                                    testSendRemember.value
                                                ).apply()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowDown,
                                            contentDescription = "-"
                                        )
                                    }
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.small_custom_padding))
                            ) {
                                Text(
                                    modifier = Modifier.clickable {
                                        isMotorRpmState.value = !isMotorRpmState.value
                                        sharedPre.edit()
                                            .putString(
                                                context.getString(R.string.testMode_testSendMode_name),
                                                if (isMotorRpmState.value) {
                                                    "0"
                                                } else {
                                                    "1"
                                                }
                                            ).apply()
                                    },
                                    text = if (isMotorRpmState.value) {
                                        "rpm"
                                    } else {
                                        "g/s"
                                    },
                                    style = TextStyle(
                                        color = Color.Black,
                                        fontFamily = FontFamily(Font(R.font.youshehaoshenti)),
                                        fontSize = 20.sp
                                    )
                                )
                                IconButton(
                                    onClick = {
                                        if (mVariableFertViewModel.serialPortIsRunning.value == false) {
                                            MySerialPortFun().openSerialPort(mVariableFertViewModel)
                                        }
                                        if (isMotorRpmState.value) {
                                            for (i in 0 until mSPParamData.rowNumber) {
                                                ConvAndCtrlFun().motorSpeedrpmSend(
                                                    testSendRemember.value.toDouble(),
                                                    i
                                                )
                                            }
                                        } else {
                                            for (i in 0 until mSPParamData.rowNumber) {
                                                val flowtoRpm =
                                                    ConvAndCtrlFun().fertflowToMotorSpeed(
                                                        testSendRemember.value.toDouble(),
                                                        fittingCoefficientA[i],
                                                        fittingCoefficientB[i]
                                                    )
                                                ConvAndCtrlFun().motorSpeedrpmSend(flowtoRpm, i)
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "发送"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2024年12月12日16:31:34，下诉代码为界面重构修改的代码
@Composable
fun MsgScreenBottom(mVariableFertViewModel: VariableFertViewModel = VariableFertViewModel()) {
    val monfertflow by mVariableFertViewModel.monfertflow.observeAsState(DoubleArray(mSPParamData.rowNumber) { 0.0 })
    val confertflow by mVariableFertViewModel.confertflow.observeAsState(DoubleArray(mSPParamData.rowNumber) { 0.0 })
    val accuracyDoublearray by mVariableFertViewModel.accuracyDoublearray.observeAsState(
        DoubleArray(
            mSPParamData.rowNumber
        ) { 0.0 })
    val fertApplied by mVariableFertViewModel.fertApplied.observeAsState(DoubleArray(mSPParamData.rowNumber) { 0.0 })
    Box(
        modifier = Modifier
            .padding(dimensionResource(id = R.dimen.small_custom_padding))
            .fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.8f)
                .fillMaxHeight(0.2f),
        ) {
            Box(
                modifier = Modifier.padding(start = 100.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val targetValue = fertApplied[mSPParamData.rowNumber / 2]
//                    BarChartWithTarget(
//                        barValues = confertflow,
//                        targetValue = targetValue,
//                        modifier = Modifier.weight(1f)
//                    )
                    BarChartWithTarget(
                        barValues = monfertflow,
                        targetValue = targetValue,
                        zoom = 0.3,
                        modifier = Modifier.weight(1f)
                    )
                    BarChartWithTarget(
                        barValues = accuracyDoublearray,
                        targetValue = 85.00,
                        zoom=0.2,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
