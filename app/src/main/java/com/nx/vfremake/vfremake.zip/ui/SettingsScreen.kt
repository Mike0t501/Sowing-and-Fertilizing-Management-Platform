/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年7月12日22:22:37
 * @file    :
 * @brief   :设置界面
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 写出保存实验数据开关
 * 颜色分级数设置
 ***********************************************************************************************************
 */
package com.nx.vfremake.ui

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Scaffold
import androidx.compose.material.Switch
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.dp
import com.nx.vfremake.R
import com.nx.vfremake.funClass.MySharedPreFun


private var backPressedTime: Long = 0

/**
 * 设置页面
 * @param  onClickBack:返回导航页面至
 * @return
 * @note
 */
@Composable
fun SettingsScreen(onClickBack: () -> Unit = {}, onClickDantiSettigns: () -> Unit = {}) {
    val context = LocalContext.current
    val sharedPre = MySharedPreFun(context).getMySharedPre()
    // 是否写出试验文本数据
    val writeSaveDataSwitchIsOnState = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.writeSaveData_Switch_name) == "1"
        )
    }
    // 是否指示补偿点位置
    val navMarkCompensatedSwitchIsOnState = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.navMarkCompensated_Switch_name) == "1"
        )
    }
    // 是否打开测试模式
    val testModeSwitchIsOnState = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.testMode_Switch_name) == "1"
        )
    }

    // 颜色分级数
    val colorStep = remember {
        mutableIntStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.colorStep_name)
                ?.toIntOrNull() ?: context.resources.getInteger(R.integer.colorStep_value)
        )
    }
    // 位置跟随区域大小
    val deltaX = remember {
        mutableIntStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.deltaX_name)
                ?.toIntOrNull() ?: context.resources.getInteger(R.integer.deltaX_value)
        )
    }
    val deltaY = remember {
        mutableIntStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.deltaY_name)
                ?.toIntOrNull() ?: context.resources.getInteger(R.integer.deltaY_value)
        )
    }
    // 测试模式测试时间
    val testModeDurationTime = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.testMode_testModeDurationTime_name)
                ?: context.getString(R.string.testMode_testModeDurationTime_defeatValue)
        )
    }
    // 求速度均值使用？次定位信息（5Hz）
    val forwardSpeedAverageNum = remember {
        mutableStateOf(
            MySharedPreFun(context).getSpecificValue(R.string.forwardSpeedAverageNum_name)
                ?: context.getString(R.string.forwardSpeedAverageNum_defeatValue)
        )
    }

    Scaffold(
        topBar = {
            MyTopBar(
                title = "设置",
                onClickBack = {
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - backPressedTime < 1000) {
                        Log.d("TopBar", "返回防抖已运行")
                        return@MyTopBar
                    }
                    backPressedTime = currentTime
                    onClickBack()
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(innerPadding),
        ) {
            Column(
                modifier = Modifier.padding(dimensionResource(id = R.dimen.big_view_padding)),
                verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding))
            ) {
                TemplatesSettingsRow(
                    text = "测试模式",
                    onLongClick = onClickDantiSettigns,
                    content = {
                        MyDiyTextField(
                            label = "时间(s): ",
                            modifier = Modifier.width(150.dp),
                            value = testModeDurationTime.value,
                            onValueChange = { newText ->
                                testModeDurationTime.value = newText
                                sharedPre.edit().putString(
                                    context.getString(R.string.testMode_testModeDurationTime_name),
                                    newText
                                )
                                    .apply()
                            }
                        )
                        Switch(
                            modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                            checked = testModeSwitchIsOnState.value,
                            onCheckedChange = { newValue ->
                                // 更新开关状态
                                testModeSwitchIsOnState.value = newValue
                                // 保存开关状态到 SharedPreferences
                                val valueToSave = if (newValue) "1" else "0"

                                sharedPre.edit().putString(
                                    context.getString(R.string.testMode_Switch_name),
                                    valueToSave
                                ).apply()
                            }
                        )
                    }
                )
                TemplatesSettingsRow(
                    text = "N次速度均值定速",
                    content = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.small_custom_padding))
                        ) {
                            MyDiyTextField(
                                label = forwardSpeedAverageNum.value + "*200 " + "ms",
                                modifier = Modifier
                                    .padding(end = dimensionResource(id = R.dimen.big_view_padding))
                                    .width(150.dp),
                                value = forwardSpeedAverageNum.value,
                                onValueChange = { newValue ->
                                    forwardSpeedAverageNum.value = newValue
                                    sharedPre.edit().putString(
                                        context.getString(R.string.forwardSpeedAverageNum_name),
                                        newValue
                                    ).apply()
                                }
                            )
                        }
                    }
                )

                TemplatesSettingsRow(
                    text = "保存实验数据",
                    content = {
                        Switch(
                            modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                            checked = writeSaveDataSwitchIsOnState.value,
                            onCheckedChange = { newValue ->
                                // 更新开关状态
                                writeSaveDataSwitchIsOnState.value = newValue
                                // 保存开关状态到 SharedPreferences
                                val valueToSave = if (newValue) "1" else "0"

                                sharedPre.edit().putString(
                                    context.getString(R.string.writeSaveData_Switch_name),
                                    valueToSave
                                ).apply()
                            }
                        )
                    }
                )
                TemplatesSettingsRow(
                    text = "显示补偿位置",
                    content = {
                        Switch(
                            modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                            checked = navMarkCompensatedSwitchIsOnState.value,
                            onCheckedChange = { newValue ->
                                // 更新开关状态
                                navMarkCompensatedSwitchIsOnState.value = newValue
                                // 保存开关状态到 SharedPreferences
                                val valueToSave = if (newValue) "1" else "0"

                                sharedPre.edit().putString(
                                    context.getString(R.string.navMarkCompensated_Switch_name),
                                    valueToSave
                                ).apply()
                            }
                        )
                    }
                )
                TemplatesSettingsRow(
                    text = "颜色分级数(不包含0域)",
                    content = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(
                                dimensionResource(
                                    id = R.dimen.small_custom_padding
                                )
                            )
                        ) {
                            MyDiyTextField(
                                modifier = Modifier.width(100.dp),
                                value = colorStep.intValue.toString(),
                                readOnly = true
                            )
                            Column(
                                modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                // 加号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        colorStep.intValue++
                                        sharedPre.edit()
                                            .putString(
                                                context.getString(R.string.colorStep_name),
                                                colorStep.intValue.toString()
                                            ).apply()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowUp,
                                        contentDescription = "+"
                                    )
                                }

                                // 减号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        if (colorStep.intValue >= 2) {
                                            colorStep.intValue--
                                            sharedPre.edit()
                                                .putString(
                                                    context.getString(R.string.colorStep_name),
                                                    colorStep.intValue.toString()
                                                ).apply()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "-"
                                    )
                                }
                            }
                        }
                    }
                )
                TemplatesSettingsRow(
                    text = "跟随当前位置视图大小(*10^-6)",
                    content = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(
                                dimensionResource(
                                    id = R.dimen.small_custom_padding
                                )
                            )
                        ) {
                            MyDiyTextField(
                                label = "X",
                                modifier = Modifier.width(100.dp),
                                value = deltaX.intValue.toString(),
                                readOnly = true
                            )
                            Column(
                                modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                // 加号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        deltaX.intValue += 5
                                        sharedPre.edit()
                                            .putString(
                                                context.getString(R.string.deltaX_name),
                                                deltaX.intValue.toString()
                                            ).apply()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowUp,
                                        contentDescription = "+"
                                    )
                                }

                                // 减号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        if (deltaX.intValue >= 10) {
                                            deltaX.intValue -= 5
                                            sharedPre.edit()
                                                .putString(
                                                    context.getString(R.string.deltaX_name),
                                                    deltaX.intValue.toString()
                                                ).apply()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "-"
                                    )
                                }
                            }
                            MyDiyTextField(
                                label = "Y",
                                modifier = Modifier.width(100.dp),
                                value = deltaY.intValue.toString(),
                                readOnly = true
                            )
                            Column(
                                modifier = Modifier.padding(end = dimensionResource(id = R.dimen.middle_view_padding)),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                // 加号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        deltaY.intValue += 5
                                        sharedPre.edit()
                                            .putString(
                                                context.getString(R.string.deltaY_name),
                                                deltaY.intValue.toString()
                                            ).apply()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowUp,
                                        contentDescription = "+"
                                    )
                                }

                                // 减号按钮
                                IconButton(
                                    modifier = Modifier.size(20.dp),
                                    onClick = {
                                        if (deltaY.intValue >= 10) {
                                            deltaY.intValue -= 5
                                            sharedPre.edit()
                                                .putString(
                                                    context.getString(R.string.deltaY_name),
                                                    deltaY.intValue.toString()
                                                ).apply()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "-"
                                    )
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}
