/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年7月12日22:40:23
 * @file    :
 * @brief   :参数设置页面
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 横竖屏布局
 * 参数设置
 * 长按提示
 ***********************************************************************************************************
 */
package com.nx.vfremake.ui

import android.content.res.Configuration
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nx.vfremake.R
import com.nx.vfremake.funClass.MySharedPreFun


/**
 * 参数设置页面视图合集
 * @param  onClickBack:点击返回导航页面至
 * @return
 * @note
 */
@Composable
fun ParamSettingsScreen(
    onClickBack: () -> Unit = {}
) {
    // 判断屏幕是横屏还是竖屏
    val isPortrait =
        LocalConfiguration.current.orientation == Configuration.ORIENTATION_PORTRAIT

    // 根据屏幕方向选择不同的布局
    if (isPortrait) {
        ParamSettingsPortraitScreen(onClickBack) { ParamSettingsTextSection() }
    } else {
        ParamSettingsLandscapeScreen(onClickBack) { ParamSettingsTextSection() }
    }
    ParamSettingsResetAndApply()
}

/**
 * 横竖屏布局共用参数设置文字部分
 * @note
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ParamSettingsTextSection() {
    val context = LocalContext.current
    val sharedPre = MySharedPreFun(context).getMySharedPre()

    val rowSize =
        rememberSaveable {
            mutableStateOf(
                sharedPre.getString(context.getString(R.string.rowSize_name), "") ?: ""
            )
        }
    val gnssDistanceVertical = rememberSaveable {
        mutableStateOf(
            sharedPre.getString(context.getString(R.string.gnssDistanceVertical_name), "") ?: ""
        )
    }
    val gnssDistanceHorizontal = rememberSaveable {
        mutableStateOf(
            sharedPre.getString(context.getString(R.string.gnssDistanceHorizontal_name), "") ?: ""
        )
    }
    val lagTime =
        rememberSaveable {
            mutableStateOf(
                sharedPre.getString(context.getString(R.string.lagTime_name), "") ?: ""
            )
        }
    val rowNumber =
        rememberSaveable {
            mutableStateOf(
                sharedPre.getString(context.getString(R.string.rowNumber_name), "") ?: ""
            )
        }
    val forwardSpeed =
        rememberSaveable {
            mutableStateOf(
                sharedPre.getString(context.getString(R.string.forwardSpeed_name), "") ?: ""
            )
        }
    val fertApplied =
        rememberSaveable {
            mutableStateOf(
                sharedPre.getString(context.getString(R.string.fertApplied_name), "") ?: ""
            )
        }
    FlowRow(
        verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.middle_view_padding)),
    ) {
        TemplatesText_FieldUint(
            title = "行距RS",
            value = rowSize.value,
            uint = "cm",
            onValueChange = { newText ->
                rowSize.value = newText
                sharedPre.edit().putString(context.getString(R.string.rowSize_name), newText)
                    .apply()
            }
        )
        TemplatesText_FieldUint(
            title = "GNSS距离L1",
            value = gnssDistanceVertical.value,
            uint = "cm",
            onValueChange = { newText ->
                gnssDistanceVertical.value = newText
                sharedPre.edit()
                    .putString(context.getString(R.string.gnssDistanceVertical_name), newText)
                    .apply()
            }
        )
        TemplatesText_FieldUint(
            title = "GNSS距离L2",
            value = gnssDistanceHorizontal.value,
            uint = "cm",
            onValueChange = { newText ->
                gnssDistanceHorizontal.value = newText
                sharedPre.edit()
                    .putString(context.getString(R.string.gnssDistanceHorizontal_name), newText)
                    .apply()
            }
        )
        TemplatesText_FieldUint(
            title = "滞后时间T",
            value = lagTime.value,
            uint = "s",
            onValueChange = { newText ->
                lagTime.value = newText
                sharedPre.edit().putString(context.getString(R.string.lagTime_name), newText)
                    .apply()
            }
        )
        TemplatesText_FieldUint(
            title = "行数N: ",
            value = rowNumber.value,
            uint = "行",
            onValueChange = { newText ->
                rowNumber.value = newText
                sharedPre.edit().putString(context.getString(R.string.rowNumber_name), newText)
                    .apply()
            }
        )
        TemplatesText_FieldUint(
            title = "前进速度",
            value = forwardSpeed.value,
            uint = "km/h",
            onValueChange = { newText ->
                forwardSpeed.value = newText
                sharedPre.edit()
                    .putString(context.getString(R.string.forwardSpeed_name), newText).apply()
            }
        )
        TemplatesText_FieldUint(
            title = "施肥量",
            value = fertApplied.value,
            uint = "kg/亩",
            onValueChange = { newText ->
                fertApplied.value = newText
                sharedPre.edit().putString(context.getString(R.string.fertApplied_name), newText)
                    .apply()
            }
        )
    }
}

private var backPressedTime: Long = 0

/**
 * 参数设置页面横屏布局
 * @param  onClickBack:从参数设置界面返回至
 * @param  content:横竖屏共用部分compose
 * @note   这里注入sharedPreferences读取设置数据
 */
@Composable
fun ParamSettingsLandscapeScreen(onClickBack: () -> Unit = {}, content: @Composable () -> Unit) {
    Scaffold(
        topBar = {
            MyTopBar(
                title = "参数设置",
                onClickBack = {
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - backPressedTime < 1000) {
                        Log.d("TopBar", "返回防抖已运行")
                        return@MyTopBar
                    }
                    backPressedTime = currentTime
                    onClickBack()
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) { // 整体布局为垂直分布的Column
            Row(
                horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.small_view_padding)),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val image = painterResource(id = R.drawable.fertilizationdiagram)
                val imageRatio = image.intrinsicSize.width / image.intrinsicSize.height
                Image(
                    painter = painterResource(id = R.drawable.fertilizationdiagram),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(5f)
                        .aspectRatio(imageRatio),
                    contentScale = ContentScale.Crop,
                )

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(4f), //使用weight来设置占比
                    contentAlignment = Alignment.Center,
                ) {
                    content()
                }
            }
        }
    }
}


/**
 * 参数设置页面竖屏布局
 * @param  onClickBack:从参数设置界面返回所要实现功能
 * @param  content:横竖屏共用部分compose
 * @note   这里注入sharedPreferences读取设置数据
 */
@Composable
fun ParamSettingsPortraitScreen(onClickBack: () -> Unit = {}, content: @Composable () -> Unit) {
    var backPressedTime: Long = 0
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "参数设置",
                        style = TextStyle(
                            fontWeight = FontWeight.W600,
                            fontSize = 24.sp,
                            letterSpacing = 6.sp
                        ),
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        val currentTime = System.currentTimeMillis()
                        if (currentTime - backPressedTime < 1000) {
                            return@IconButton
                        }
                        backPressedTime = currentTime
                        onClickBack()
                    }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "返回"
                        )
                    }
                },
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.small_view_padding))
        ) { // 整体布局为垂直分布的Column
            val image = painterResource(id = R.drawable.fertilizationdiagram)
            val imageRatio = image.intrinsicSize.width / image.intrinsicSize.height
            Image(
                painter = painterResource(id = R.drawable.fertilizationdiagram),
                contentDescription = null,
                modifier = Modifier
                    .padding(top = 50.dp)
                    .align(Alignment.CenterHorizontally)
                    .fillMaxWidth(0.75f)
                    .weight(3f)
                    .aspectRatio(imageRatio),
                contentScale = ContentScale.Crop,
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(4f), //使用weight来设置占比
                contentAlignment = Alignment.Center,
            ) {
                content()
            }
        }
    }
}

/**
 * 参数设置页面应用、重置按钮
 * @note
 */
@Composable
fun ParamSettingsResetAndApply() {
    val sharedPreHelper = MySharedPreFun(LocalContext.current)
    //... 防止重置参数误触操作
    val paramResetState = remember { mutableStateOf(false) }
    if (paramResetState.value) {
        ShowConfirmDialog(
            title = "重置参数",
            text = "你确实要重置参数吗？",
            onConfirm = {
                sharedPreHelper.resetConfig()
                sharedPreHelper.initSettingsParam()
            },
            showDialog = paramResetState
        )
    }
    //... 防止重置参数误触操作结束
    Box(
        modifier = Modifier
            .padding(dimensionResource(id = R.dimen.big_view_padding))
            .fillMaxSize(),
        contentAlignment = Alignment.BottomEnd
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = dimensionResource(id = R.dimen.big_view_padding))
                .height(30.dp)
                .align(Alignment.BottomEnd),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(id = R.dimen.big_view_padding))
        ) {
            IconButton(onClick = { sharedPreHelper.initSettingsParam() }) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Filled.DoneAll, contentDescription = "应用")
                    Text(
                        text = "应用",
                    )
                }
            }
            IconButton(onClick = { paramResetState.value = true }) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.SettingsBackupRestore,
                        contentDescription = "重置"
                    )
                    Text(
                        text = "重置",
                    )
                }
            }
        }
    }
}
