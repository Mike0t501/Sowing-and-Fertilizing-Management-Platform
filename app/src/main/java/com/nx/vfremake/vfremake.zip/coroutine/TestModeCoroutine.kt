package com.nx.vfremake.coroutine

import android.content.Context
import androidx.compose.runtime.MutableState
import com.nx.vfremake.R
import com.nx.vfremake.fittingCoefficientA
import com.nx.vfremake.fittingCoefficientB
import com.nx.vfremake.funClass.ConvAndCtrlFun
import com.nx.vfremake.funClass.MySharedPreFun
import com.nx.vfremake.mSPParamData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class TestModeCoroutine {
    // 定义一个协程作用域，保存作业引用的HashSet，以便于管理
    private val scope = CoroutineScope(Dispatchers.Default)
    private val jobs = HashSet<Job>()

    // 开始标志位
    var isRunning = false

    fun shutdown() {
        jobs.forEach { it.cancel() }
        jobs.clear() // 清空作业记录
        isRunning = false
    }

    fun start(context: Context, isRunningState: MutableState<Boolean>) {
        var elapsedTime = 0L
        val testModeDurationTime = ((
                MySharedPreFun(context).getSpecificValue(R.string.testMode_testModeDurationTime_name)
                    ?.toIntOrNull()
                    ?: context.getString(R.string.testMode_testModeDurationTime_defeatValue).toInt()
                ) * 1000).toLong()
        val testSend =
            (MySharedPreFun(context).getSpecificValue(R.string.testMode_testSend_name)
                ?: context.getString(R.string.testMode_testSend_defeatValue))
                .toDouble()
        val testSendMode =
            (MySharedPreFun(context).getSpecificValue(R.string.testMode_testSendMode_name))
                ?: context.getString(R.string.testMode_testSendMode_defeatValue)

        jobs.add(scope.launch {
            isRunning = true
            while (elapsedTime < testModeDurationTime) {
                delay(200) // 每200毫秒发送一次数据
                elapsedTime += 200
                if (testSendMode == "0") {
                    for (i in 0 until mSPParamData.rowNumber) {
                        ConvAndCtrlFun().motorSpeedrpmSend(
                            testSend,
                            i
                        )
                    }
                } else {
                    for (i in 0 until mSPParamData.rowNumber) {
                        val flowtoRpm =
                            ConvAndCtrlFun().fertflowToMotorSpeed(
                                testSend,
                                fittingCoefficientA[i],
                                fittingCoefficientB[i]
                            )
                        ConvAndCtrlFun().motorSpeedrpmSend(
                            flowtoRpm,
                            i
                        )
                    }
                }
            }
            // 停止时电机也停止
            for (i in 0 until mSPParamData.rowNumber) {
                ConvAndCtrlFun().motorSpeedrpmSend(
                    0.0,
                    i
                )
            }
            shutdown()
            isRunningState.value = false
        })
    }
}
