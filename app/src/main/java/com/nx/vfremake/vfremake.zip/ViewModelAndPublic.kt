/**
 ***********************************************************************************************************
 * @author  :NIANXI
 * @date    :2024年6月27日10:55:24
 * @file    :
 * @brief   :public总集
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 地图有关viewm
 * 信息有关viewmodel
 * data class RMC解析存储
 ***********************************************************************************************************
 */
package com.nx.vfremake

import android.content.Intent
import android.serialport.SerialPort
import androidx.activity.result.ActivityResultLauncher
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.esri.arcgisruntime.data.ShapefileFeatureTable
import com.esri.arcgisruntime.geometry.Point
import com.esri.arcgisruntime.layers.FeatureLayer
import com.esri.arcgisruntime.mapping.ArcGISMap
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay
import com.nx.vfremake.funClass.RmcData
import com.nx.vfremake.funClass.SPParamData
import kotlinx.coroutines.Job

// ax+b
lateinit var fittingCoefficientA: Array<Double>
lateinit var fittingCoefficientB: Array<Double>

// 串口
var mSerialPortDB9: SerialPort? = null
var mSerialPortCAN: SerialPort? = null

// 字段
lateinit var fertQueryField: String

// RMC解析存储data
var mRmcData = RmcData()

// 接收导航信息CNT计数


// public 数据，很多地方需要使用，用户设置的数据 data class
var mSPParamData = SPParamData()

lateinit var selectLoadShpFileLauncher: ActivityResultLauncher<Intent>

class CustomViewModel : ViewModel() {
    var copyShpFilesJob: Job? = null

}

// 地图有关的viewmodel
class VariableFertViewModel : ViewModel() {
    val mArcGISMap = MutableLiveData<ArcGISMap>() // ArcGISMap
    val shapefileFeatureLayer = MutableLiveData<FeatureLayer>()
    val shapefileFeatureTable = MutableLiveData<ShapefileFeatureTable>()

    val loLaDidegData = MutableLiveData<Triple<Double, Double, Double>>()  // navMark 经度、纬度、航向角未补偿
    val forwardspeed = MutableLiveData(0.0) // 前进速度

    val navMarkGraphicsOverlay = MutableLiveData<GraphicsOverlay>() // navMark 图层
    val fertGraphicsOverlay = MutableLiveData<GraphicsOverlay>() // 已施肥区域图层
    val fertGraphicsOverlayExport = MutableLiveData<GraphicsOverlay>() // 已施肥区域图层
    val mapViewRotation = MutableLiveData(0.0) // 已施肥区域图层

    // 颜色分级与范围
    var colorList = MutableLiveData<List<Int>>() // 颜色分级提示用
    val classBreaksList = MutableLiveData<List<String>>()

    // 字段列表，更换处方图使用
    val fieldsList = MutableLiveData<List<String>>()

    val dantiLLGeo = MutableLiveData<Array<Point>>() // 单体地理坐标
    val drawLLGeo = MutableLiveData<Array<Point>>() // 单体地理坐标

    val monfertflow = MutableLiveData<DoubleArray>() // 监测施肥量monitor
    val monAdcV = MutableLiveData<DoubleArray>() // 监测电压
    val confertflow = MutableLiveData<DoubleArray>() // 转速转换施肥量convert
    val motorSpeed = MutableLiveData<DoubleArray>() // 转速
    val fertApplied = MutableLiveData<DoubleArray>() // 应施肥量
    val fertAppliedLast = MutableLiveData<DoubleArray>() // 上次应施肥量

    val msgCNT = MutableLiveData(0)
    val forwardSpeedArraySum = MutableLiveData(0.0)

    val navCenterIsRunning = MutableLiveData(false)
    val gnssIsGood = MutableLiveData(true)
    val serialPortIsRunning = MutableLiveData(false)

    val accuracyDoublearray= MutableLiveData<DoubleArray>()// 测试用

}
