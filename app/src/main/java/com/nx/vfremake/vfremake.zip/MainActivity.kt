/**
 ************************************************************************************************************
 * @author  :NIANXI
 * @date    :2024-05-02
 * @file    :
 * @brief   :变量施肥
 * ---------------------------------------------------------------------------------------------------------
 *                                         Change History
 * ---------------------------------------------------------------------------------------------------------
 * 分级渲染
 * 增加颜色施肥量提示
 * 位置补偿并求单体位置查询施肥量
 * DB9通讯 CAN通讯，通过按钮启停通讯线程
 * 数据保存、按钮启停保存数据协程
 ***********************************************************************************************************
 */

package com.nx.vfremake

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.esri.arcgisruntime.ArcGISRuntimeEnvironment
import com.esri.arcgisruntime.mapping.view.BackgroundGrid
import com.esri.arcgisruntime.mapping.view.MapView
import com.nx.vfremake.coroutine.CanReceiveCoroutine
import com.nx.vfremake.coroutine.DB9reCANseCoroutine
import com.nx.vfremake.coroutine.MyWriteSaveFun
import com.nx.vfremake.coroutine.TestModeCoroutine
import com.nx.vfremake.funClass.ConvAndCtrlFun
import com.nx.vfremake.funClass.DocuAndManageFun
import com.nx.vfremake.funClass.MyArcGisFun
import com.nx.vfremake.funClass.MySerialPortFun
import com.nx.vfremake.funClass.MySharedPreFun
import com.nx.vfremake.funClass.MydantiFertSharedPre
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // viewmodel
    private val customViewModel: CustomViewModel by viewModels()
    private val mVariableFertViewModel: VariableFertViewModel by viewModels()

    private lateinit var mapView: MapView

    // 协程
    // 注意初始化的传参，如果在这里初始化，有些public参数为null时就传入，导致报错
    // 需要修改协程里的代码，比如在start处传参或者start里使用public参数
    private val myWriteSaveFun = MyWriteSaveFun()
    private val myTestModeCoroutine = TestModeCoroutine()

    // 因为需要rowNumber初始化参数，必须mSPParamData初始化完成才初始化
    private lateinit var mDB9reCANseCoroutine: DB9reCANseCoroutine
    private var mCanReceiveCoroutine = CanReceiveCoroutine()

    // 定义ActivityResultLauncher用于对象选择
    private lateinit var selectWriteDirectoryLauncher: ActivityResultLauncher<Uri?>

    //...oncreat开始
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VariableFert(
                mapView,
                mVariableFertViewModel,
            ) { StartAndStopBottom() }
        }

        // 首次运行需要将assets里的资源复制到外部专属目录files/shpFile/下
        val firstRunState = MySharedPreFun(this).getSpecificValue(R.string.runForTheFirstTime)
        if (firstRunState != "1") {
            customViewModel.copyShpFilesJob = lifecycleScope.launch(Dispatchers.Default) {
                DocuAndManageFun().copyShpFilesToExternalStorage(this@MainActivity)
            }
        }

        // 设置apikey使用功能，申请apikey在arcgis的官方developer网站
        // https://developers.arcgis.com/dashboard/
        // 如果需要更改apikey，前往build.gradle:app里更改
        // 去除水印需要license，因为使用了限制级内容，免费的lite license不顶用 T_T
        // https://developers.arcgis.com/qt/license-and-deployment/get-a-license/
        ArcGISRuntimeEnvironment.setApiKey(BuildConfig.API_KEY)
//        ArcGISRuntimeEnvironment.setLicense(BuildConfig.Lite_License)

        // 查询所有SerialPort调试用
//        SerialPortFinder().allDevices

        // 初始化selectDirectoryLauncher
        selectWriteDirectoryLauncher =
            selectDirectoryLauncher(R.string.myWriteDir_DocumentUri_name, this)
        selectLoadShpFileLauncher =
            selectShpFileLauncher(R.string.myLoadShpFile_Path_name, this)

        // 屏幕常亮
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val colorArgbBackgrand = this.getColor(R.color.background_color_default)
        // 初始化mapview
        mapView = MapView(this).apply {
            // 初始设置，例如设置背景、栅格颜色等
            isAttributionTextVisible = false
            setBackgroundColor(colorArgbBackgrand)
            backgroundGrid = BackgroundGrid(colorArgbBackgrand, colorArgbBackgrand, 0f, 2f)
        }

        // loadShp识别了字段值和路径是否有效，无效是不会执行加载地图操作的
        MyArcGisFun().loadShp(this, mVariableFertViewModel)
    }
    //...oncreat结束

    /**
     * 注册文件夹选择
     * @param  resId:写出保存数据文件夹资源值ID
     * @param  context:上下文
     * @return
     * @note
     */
    private fun selectDirectoryLauncher(
        resId: Int,
        context: Context,
    ): ActivityResultLauncher<Uri?> {
        return registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            // 处理用户选择的对象
            uri?.also {
                // 获取持久URI访问权限
                val takeFlags: Int =
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)

                // 保存Uri至SharedPreferences并持久化权限
                // 这里保存之后其他地方调用不要覆盖了用户选择文件夹存储的字段，使用新字段
                val sharedPreHelper = MySharedPreFun(context)
                // uri安全调用了这里不为空
                sharedPreHelper.persistDirectoryUriPermission(
                    uri,
                    takeFlags,
                    context.getString(resId)
                )
                //...写出文件测试代码
                MyWriteSaveFun().writeFileToSelectedDirectory(
                    "writetest.txt",
                    "Hello, World!",
                    context.getString(resId),
                    context
                )
                //...
            }
        }
    }

    /**
     * 注册选择shp地图
     * @param  resId:存储shp路径的资源值ID
     * @param  context:上下文
     * @return
     * @note   这里保存了路径，以及列出了字段供选择
     */
    private fun selectShpFileLauncher(
        resId: Int,
        context: Context,
    ): ActivityResultLauncher<Intent> {
        return registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                uri?.let {
                    if (uri.toString().endsWith(".shp")) {
                        val filePath = DocuAndManageFun().getPathFromContentUri(context, uri)
                        Log.d("SharedPre", filePath.toString())
                        MySharedPreFun(context).getMySharedPre().edit()
                            .putString(context.getString(resId), filePath).apply()
                        MyArcGisFun().getFieldList(filePath, mVariableFertViewModel)
                    } else {
                        // 不是 .shp 文件提示
                        AlertDialog.Builder(context)
                            .setTitle("文件选择错误")
                            .setMessage("请选择 .shp 文件")
                            .setPositiveButton("确定", null)
                            .show()
                    }
                }
            }
        }
    }

    /**
     * 启停通讯线程和写出保存数据协程按钮
     * @note
     */
    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    fun StartAndStopBottom() {
        val context = LocalContext.current

        Box(
            modifier = Modifier
                .padding(dimensionResource(id = R.dimen.small_custom_padding))
                .fillMaxSize()
        ) {
            val configuration = LocalConfiguration.current
            val isInPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT
            // 协程启动标志位
            val isRunningState = remember { mutableStateOf(false) }

            FlowRow(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .fillMaxWidth(0.2f),
                maxItemsInEachRow = if (isInPortrait) 1 else 2,
                horizontalArrangement = Arrangement.Center,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = if (isRunningState.value) androidx.compose.ui.graphics.Color.Gray
                    else androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier
                        .width(90.dp)
                        .padding((dimensionResource(id = R.dimen.middle_view_padding))),
                    shape = RoundedCornerShape(dimensionResource(id = R.dimen.small_roundedCornerShape)),
                ) {
                    IconButton(
                        onClick = {
                            if (!isRunningState.value) {

                                //...保存实验数据开始
                                // 检查保存数据写出权限
                                DocuAndManageFun().cheekDirectoryUriPermission(
                                    R.string.myWriteDir_DocumentUri_name,
                                    selectWriteDirectoryLauncher,
                                    context
                                )
                                // 如果写出权限正常并且保存试验数据为开，则写出数据
                                if (MySharedPreFun(context).getSpecificValue(R.string.writeSaveData_Switch_name) == "1") {
                                    myWriteSaveFun.start(context = context, getData = {
                                        myWriteSaveFun.getMySaveData(
                                            mSPParamData.rowNumber,
                                            mVariableFertViewModel
                                        )
                                    })
                                }
                                //...保存实验数据结束

                                // 先打开串口，在打开接收线程
                                if (mVariableFertViewModel.serialPortIsRunning.value == false) {
                                    MySerialPortFun().openSerialPort(mVariableFertViewModel)
                                }

                                isRunningState.value = true

                                if (MySharedPreFun(context).getSpecificValue(R.string.testMode_Switch_name) == "1" && !myTestModeCoroutine.isRunning) {
                                    myTestModeCoroutine.start(context, isRunningState)
                                } else {
                                    if (!mDB9reCANseCoroutine.isRunning) {
                                        mDB9reCANseCoroutine.start1(context, mVariableFertViewModel)
                                    }
                                    if (!mCanReceiveCoroutine.isRunning) {
                                        mCanReceiveCoroutine.start(mVariableFertViewModel)
                                    }
                                }
                            }
                        },
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.PlayCircle, contentDescription = "开始")
                            Text("开始")
                        }
                    }
                }
                Surface(
                    color = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier
                        .width(90.dp)
                        .padding((dimensionResource(id = R.dimen.middle_view_padding))),
                    shape = RoundedCornerShape(dimensionResource(id = R.dimen.small_roundedCornerShape)),
                ) {
                    IconButton(
                        onClick = {
                            // 停止时电机也停止
                            for (i in 0 until mSPParamData.rowNumber) {
                                ConvAndCtrlFun().motorSpeedrpmSend(
                                    0.0,
                                    i
                                )
                            }
                            releaseResource(mVariableFertViewModel)

                            if (mDB9reCANseCoroutine.isRunning) {
                                myWriteSaveFun.shutdown()
                            }
                            if (myTestModeCoroutine.isRunning) {
                                myTestModeCoroutine.shutdown()
                            }
                            if (isRunningState.value) {
                                isRunningState.value = false
                            }
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.StopCircle,
                                contentDescription = "停止",
                            )
                            Text(text = "停止")
                        }
                    }
                }
            }
        }
    }

    // 开始时读取用户保存数据
    override fun onStart() {
        super.onStart()
        val sharedPreHelper = MySharedPreFun(this)
        sharedPreHelper.updataNewConfig()

        //... SharePrefrences测试代码
        val resKey = this.getString(R.string.myLoadShpFile_Path_name)
        val keyValue = sharedPreHelper.getMySharedPre().getString(resKey, "")
        // 根据读取的值进行验证
        if (keyValue.equals("-1")) {
            Log.d("SharedPreferences", "$resKey 不存在或为空")
        } else {
            Log.d("SharedPreferences", "$resKey 已存在: $keyValue")
        }
        //...

        sharedPreHelper.initSettingsParam()
        mDB9reCANseCoroutine = DB9reCANseCoroutine()
        initFittingCoefficient()
        Log.d(
            "Coefficient",
            "A:" + fittingCoefficientA.joinToString(separator = ", ") +
                    "\nB:" + fittingCoefficientB.joinToString(separator = ", ")
        )
        //...
    }

    /**
     * 初始化系数
     * @return
     * @note
     */
    private fun initFittingCoefficient() {
        fittingCoefficientA = Array(mSPParamData.rowNumber) { 0.0 }
        fittingCoefficientB = Array(mSPParamData.rowNumber) { 0.0 }

        val tableRows = MydantiFertSharedPre(this).getTableRows()
        tableRows.forEach { row ->
            // 系数存储0123单体对应存储的tableRow是1234,0为总的
            if (row.id <= mSPParamData.rowNumber && row.id != 0) {
                fittingCoefficientA[row.id - 1] = row.a.toDouble()
                fittingCoefficientB[row.id - 1] = row.b.toDouble()
            }
        }
        // 查找id为0的行，获取其系数A和B作为默认值
        val defaultCoefficientA = tableRows.find { it.id == 0 }?.a?.toDouble() ?: 0.0
        val defaultCoefficientB = tableRows.find { it.id == 0 }?.b?.toDouble() ?: 0.0

        // 填充未被赋值的部分为默认系数
        fittingCoefficientA.forEachIndexed { index, value ->
            if (value == 0.0) {
                fittingCoefficientA[index] = defaultCoefficientA
            }
        }
        fittingCoefficientB.forEachIndexed { index, value ->
            if (value == 0.0) {
                fittingCoefficientB[index] = defaultCoefficientB
            }
        }
    }

    private var lastBackPressTime: Long = 0 // 用于存储上一次按下返回键的时间戳
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // 获取当前时间戳
            val currentTime = System.currentTimeMillis()

            // 检查两次按下返回键的时间间隔
            if (currentTime - lastBackPressTime < 1000) { // 小于 1000 豪秒认为是退出
                finish() // 关闭当前活动，会自动触发onDestroy()
                return true
            } else {
                // 更新上一次按下返回键的时间戳
                lastBackPressTime = currentTime
                Toast.makeText(this, "再按一次退出应用", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseResource(mVariableFertViewModel)
        mapView.dispose()
    }

    /**
     * 释放串口资源
     * @note   一定是先关闭线程再关闭串口，否则输出流关闭后线程无法获取数据会报错
     */
    private fun releaseResource(viewModel: VariableFertViewModel) {
        // 如果线程还开着，那么先关闭线程
        if (mDB9reCANseCoroutine.isRunning || mCanReceiveCoroutine.isRunning) {
            mDB9reCANseCoroutine.shutdown()
            mCanReceiveCoroutine.shutdown()
        }
        if (viewModel.serialPortIsRunning.value == true) {
            MySerialPortFun().releaseSerialPort(mVariableFertViewModel)
        }
    }
}
